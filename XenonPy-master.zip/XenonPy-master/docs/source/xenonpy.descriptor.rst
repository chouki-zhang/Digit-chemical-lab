xenonpy.descriptor package
==========================

Submodules
----------

xenonpy.descriptor.base module
------------------------------

.. automodule:: xenonpy.descriptor.base
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.descriptor.cgcnn module
-------------------------------

.. automodule:: xenonpy.descriptor.cgcnn
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.descriptor.compositions module
--------------------------------------

.. automodule:: xenonpy.descriptor.compositions
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.descriptor.fingerprint module
-------------------------------------

.. automodule:: xenonpy.descriptor.fingerprint
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.descriptor.frozen\_featurizer module
--------------------------------------------

.. automodule:: xenonpy.descriptor.frozen_featurizer
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.descriptor.structure module
-----------------------------------

.. automodule:: xenonpy.descriptor.structure
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: xenonpy.descriptor
   :members:
   :undoc-members:
   :show-inheritance:
