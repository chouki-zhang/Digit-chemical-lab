xenonpy.contrib.foo.descriptor package
======================================

Submodules
----------

xenonpy.contrib.foo.descriptor.foo module
-----------------------------------------

.. automodule:: xenonpy.contrib.foo.descriptor.foo
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: xenonpy.contrib.foo.descriptor
   :members:
   :undoc-members:
   :show-inheritance:
