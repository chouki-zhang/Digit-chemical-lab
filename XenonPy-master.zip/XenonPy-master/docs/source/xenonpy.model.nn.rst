xenonpy.model.nn package
========================

Submodules
----------

xenonpy.model.nn.layer module
-----------------------------

.. automodule:: xenonpy.model.nn.layer
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.model.nn.wrap module
----------------------------

.. automodule:: xenonpy.model.nn.wrap
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: xenonpy.model.nn
   :members:
   :undoc-members:
   :show-inheritance:
