xenonpy.contrib package
=======================

Subpackages
-----------

.. toctree::

   xenonpy.contrib.extend_descriptors
   xenonpy.contrib.foo

Module contents
---------------

.. automodule:: xenonpy.contrib
   :members:
   :undoc-members:
   :show-inheritance:
