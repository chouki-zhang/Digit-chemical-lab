xenonpy.contrib.extend\_descriptors.descriptor package
======================================================

Submodules
----------

xenonpy.contrib.extend\_descriptors.descriptor.frozen\_featurizer\_descriptor module
------------------------------------------------------------------------------------

.. automodule:: xenonpy.contrib.extend_descriptors.descriptor.frozen_featurizer_descriptor
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.contrib.extend\_descriptors.descriptor.mordred\_descriptor module
-------------------------------------------------------------------------

.. automodule:: xenonpy.contrib.extend_descriptors.descriptor.mordred_descriptor
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.contrib.extend\_descriptors.descriptor.organic\_comp\_descriptor module
-------------------------------------------------------------------------------

.. automodule:: xenonpy.contrib.extend_descriptors.descriptor.organic_comp_descriptor
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: xenonpy.contrib.extend_descriptors.descriptor
   :members:
   :undoc-members:
   :show-inheritance:
