xenonpy.model package
=====================

Subpackages
-----------

.. toctree::

   xenonpy.model.nn
   xenonpy.model.training
   xenonpy.model.utils

Submodules
----------

xenonpy.model.cgcnn module
--------------------------

.. automodule:: xenonpy.model.cgcnn
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.model.extern module
---------------------------

.. automodule:: xenonpy.model.extern
   :members:
   :undoc-members:
   :show-inheritance:

xenonpy.model.sequential module
-------------------------------

.. automodule:: xenonpy.model.sequential
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: xenonpy.model
   :members:
   :undoc-members:
   :show-inheritance:
