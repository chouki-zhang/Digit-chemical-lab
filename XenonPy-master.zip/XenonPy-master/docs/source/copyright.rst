=========
Copyright
=========

Copyright © 2019 The XenonPy task force, all rights reserved.
Released under the `BSD-3 license`_.

.. _BSD-3 license: https://opensource.org/licenses/BSD-3-Clause

