xenonpy.contrib.extend\_descriptors package
===========================================

Subpackages
-----------

.. toctree::

   xenonpy.contrib.extend_descriptors.descriptor

Module contents
---------------

.. automodule:: xenonpy.contrib.extend_descriptors
   :members:
   :undoc-members:
   :show-inheritance:
