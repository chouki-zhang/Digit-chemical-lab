xenonpy.contrib.foo package
===========================

Subpackages
-----------

.. toctree::

   xenonpy.contrib.foo.descriptor

Module contents
---------------

.. automodule:: xenonpy.contrib.foo
   :members:
   :undoc-members:
   :show-inheritance:
